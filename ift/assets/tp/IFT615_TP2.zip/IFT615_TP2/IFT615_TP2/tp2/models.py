import nn

import torch
import torch.nn as torch_nn
import torch.nn.functional as torch_F


class RegressionModel(object):
    """
    A neural network model for approximating a function that maps from real
    numbers to real numbers. The network should be sufficiently large to be able
    to approximate x * cos(x) / 4 on the interval [-2pi, 2pi] to reasonable precision.
    """
    def __init__(self):
        # Initialize your model parameters here
        # Vous devez créer les nn.Parameter içi
        # !!! VOTRE CODE ICI !!!
        pass

    def run(self, x):
        """
        Runs the model for a batch of examples.

        Le terme `batch_size` réfère au nombre d'exemples d'entraînement présents dans l'argument `x`. Par exemple,
        `batch_size` = 64 implique que `x` sera composé de 64 observations.

        Inputs:
            x: a node with shape (batch_size x 1)
        Returns:
            A node with shape (batch_size x 1) containing predicted y-values
        """
        # !!! VOTRE CODE ICI !!!
        pass

    def get_loss(self, x, y):
        """
        Computes the loss for a batch of examples.

        Vous devriez appeler la fonction `run` pour effectuer une inférence sur les données `x` et ensuite
        calculer la perte.

        Inputs:
            x: a node with shape (batch_size x 1)
            y: a node with shape (batch_size x 1), containing the true y-values
                to be used for training
        Returns: a loss node
        """
        # !!! VOTRE CODE ICI !!!
        pass

    def train(self, dataset):
        """
        Trains the model.

        Vous itérer sur des divisions en lot (batch) de dataset. Appelez la fonction `get_loss` sur chaque paire de
        donnée et d'étiquette pour ensuite mettre à jour les poids du réseau. Utilisez la fonction `dataset.iterate_once(batch_size)`
        pour créer les divisions en lot. Vous devez vous assurer que la division entre la taille de `dataset` et
        `batch_size` soit entière sans quoi le backend plante. Autrement dit, assurez-vous que len(dataset) % batch_size == 0.

        """
        # !!! VOTRE CODE ICI !!!
        pass


class FashionClassificationModel(object):
    """
    A model for clothes classification using the Fashion-MNIST dataset.

    Each clothe is a 28x28 pixel grayscale image, which is flattened
    into a 784-dimensional vector for the purposes of this model. Each entry in
    the vector is a floating point number between 0 and 1.

    The goal is to sort each clothe into one of the 10 classes.

    (See RegressionModel for more information about the APIs of different
    methods here. We recommend that you implement the RegressionModel before
    working on this part of the project.)
    """
    def __init__(self):
        # Initialize your model parameters here
        # Vous devez créer les nn.Parameter içi
        # !!! VOTRE CODE ICI !!!
        pass

    def run(self, x):
        """
        Runs the model for a batch of examples.

        Your model should predict a node with shape (batch_size x 10),
        containing scores. Higher scores correspond to greater probability of
        the image belonging to a particular class.

        Le terme `batch_size` réfère au nombre d'exemples d'entraînement présents dans l'argument `x`. Par exemple,
        `batch_size` = 64 implique que `x` sera composé de 64 observations.

        Inputs:
            x: a node with shape (batch_size x 784)
        Output:
            A node with shape (batch_size x 10) containing predicted scores
                (also called logits)
        """
        # !!! VOTRE CODE ICI !!!
        pass

    def get_loss(self, x, y):
        """
        Computes the loss for a batch of examples.

        The correct labels `y` are represented as a node with shape
        (batch_size x 10). Each row is a one-hot vector encoding the correct
        clothe class (0-9).

        Vous devriez appeler la fonction `run` pour effectuer une inférence sur les données `x` et ensuite
        calculer la perte.

        Inputs:
            x: a node with shape (batch_size x 784)
            y: a node with shape (batch_size x 10)
        Returns: a loss node
        """
        # !!! VOTRE CODE ICI !!!
        pass

    def train(self, dataset):
        """
        Trains the model.

        Vous itérer sur des divisions en lot (batch) de dataset. Appelez la fonction `get_loss` sur chaque paire de
        donnée et d'étiquette pour ensuite mettre à jour les poids du réseau. Utilisez la fonction `dataset.iterate_once(batch_size)`
        pour créer les divisions en lot. Vous devez vous assurer que la division entre la taille de `dataset` et
        `batch_size` soit entière sans quoi le backend plante. Autrement dit, assurez-vous que len(dataset) % batch_size == 0.
        """
        # !!! VOTRE CODE ICI !!!
        pass


class LanguageIDModel(object):
    """
    A model for language identification at a single-word granularity.

    (See RegressionModel for more information about the APIs of different
    methods here. We recommend that you implement the RegressionModel before
    working on this part of the project.)
    """
    def __init__(self):
        # Our dataset contains words from five different languages, and the
        # combined alphabets of the five languages contain a total of 47 unique
        # characters.
        # You can refer to self.num_chars or len(self.languages) in your code
        self.num_chars = 47
        self.languages = ["English", "Spanish", "Finnish", "Dutch", "Polish"]

        # Initialize your model parameters here
        # !!! VOTRE CODE ICI !!!
        pass

    def run(self, xs):
        """
        Runs the model for a batch of examples.

        Although words have different lengths, our data processing guarantees
        that within a single batch, all words will be of the same length (L).

        Here `xs` will be a list of length L. Each element of `xs` will be a
        node with shape (batch_size x self.num_chars), where every row in the
        array is a one-hot vector encoding of a character. For example, if we
        have a batch of 8 three-letter words where the last word is "cat", then
        xs[1] will be a node that contains a 1 at position (7, 0). Here the
        index 7 reflects the fact that "cat" is the last word in the batch, and
        the index 0 reflects the fact that the letter "a" is the inital (0th)
        letter of our combined alphabet for this task.

        Your model should use a Recurrent Neural Network to summarize the list
        `xs` into a single node of shape (batch_size x hidden_size), for your
        choice of hidden_size. It should then calculate a node of shape
        (batch_size x 5) containing scores, where higher scores correspond to
        greater probability of the word originating from a particular language.

        Inputs:
            xs: a list with L elements (one per character), where each element
                is a node with shape (batch_size x self.num_chars)
        Returns:
            A node with shape (batch_size x 5) containing predicted scores
                (also called logits)
        """
        # !!! VOTRE CODE ICI !!!
        pass

    def get_loss(self, xs, y):
        """
        Computes the loss for a batch of examples.

        The correct labels `y` are represented as a node with shape
        (batch_size x 5). Each row is a one-hot vector encoding the correct
        language.

        Inputs:
            xs: a list with L elements (one per character), where each element
                is a node with shape (batch_size x self.num_chars)
            y: a node with shape (batch_size x 5)
        Returns: a loss node
        """
        # !!! VOTRE CODE ICI !!!
        pass

    def train(self, dataset):
        """
        Trains the model.
        """
        # !!! VOTRE CODE ICI !!!
        pass


class PyTorchCNNFashionClassificationModel(object):
    """
    A model for clothes classification using the Fashion-MNIST dataset, using PyTorch and the convnet architecture.

    Each clothe is a 28x28 pixel grayscale image. Each entry in
    the matrix is a floating point number between 0 and 1.

    The goal is to sort each clothe into one of 10 classes.

    Référez-vous à ce tutoriel de PyTorch au besoin: https://pytorch.org/tutorials/beginner/blitz/cifar10_tutorial.html
    """
    def __init__(self):
        self.device = "cuda" if torch.cuda.is_available() else "cpu"

        # Initialize your model parameters here
        self.model = torch_nn.Sequential(
            # !!! VOTRE CODE ICI !!!
            # torch_nn.Conv2d(...),
            # ...,
            # ...
        )

        self.loss_fonction = torch_nn.CrossEntropyLoss()
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=0.0001) # You can try changing the learning rate (lr=...) if you want

        self.model.to(self.device)

    def run(self, X):
        self.model.eval()
        X_tensor = torch.from_numpy(X.reshape(-1, 1, 28, 28)).to(self.device)
        logits = self.model(X_tensor)
        self.model.train()
        return logits.cpu().detach().numpy()

    def train(self, dataset):
        """
        Trains the model.
        """
        batch_size = 100 # You can try changing the size of batches (batch_size=...) if you want

        epoch_id = 0
        while True:
            self.model.train()
            for X, y in dataset.iterate_once(batch_size):
                X_tensor = torch.from_numpy(X.reshape(-1, 1, 28, 28)).to(self.device)
                y_tensor = torch.from_numpy(y).to(self.device)

                # Compute prediction and loss
                predictions = self.model(X_tensor)
                loss = self.loss_fonction(predictions, torch.argmax(y_tensor, dim=1).squeeze())

                # Backpropagation
                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()

            # Check if we reached a good enough solution.
            self.model.eval()
            val_acc = dataset.get_validation_accuracy()
            epoch_id += 1

            print(f"Epoch #{epoch_id}, validation accuracy = {val_acc}")
            if epoch_id >= 20 or val_acc >= 0.86: # You can change the maximum number of epochs (epoch_id >= ...)
                break
