import unittest

import numpy as np
from sklearn.metrics import confusion_matrix

from NaiveBayesClassifier import NaiveBayesClassifier
from sklearn.naive_bayes import MultinomialNB

from NaiveBayesClassifier import preprocess_data


class NBTestCase(unittest.TestCase):

    def test_predict(self):
        # loading data
        X_train, X_test, y_train, y_test, _, _ = preprocess_data(max_features=200)

        model = NaiveBayesClassifier()
        y_hat = model.fit(X_train, y_train).predict(X_test)
        mat = confusion_matrix(y_test, y_hat)

        skModel = MultinomialNB()
        skModel.fit(X_train, y_train)
        y_hat_sk = skModel.predict(X_test)
        mat_sk = confusion_matrix(y_test, y_hat_sk)

        np.testing.assert_array_equal(mat, mat_sk)


if __name__ == '__main__':
    unittest.main()
