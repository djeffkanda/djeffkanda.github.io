import re

import numpy as np
from sklearn.naive_bayes import MultinomialNB
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.preprocessing import LabelEncoder
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

sns.set()


class NaiveBayesClassifier:

    def __init__(self, alpha=1.0):
        self.prior = None
        self.likelihood = None
        self.alpha = alpha


    def fit(self, X: np.ndarray, y: np.ndarray):
        """Fit Naive Bayes classifier according to X, y

        Parameters
        ----------
        X : array of shape (n_samples, n_features)
            Training vectors, where n_samples is the number of samples and
            n_features is the number of features.

        y : array of shape (n_samples,)
            Target values.
        """

        n = X.shape[0]
        nb_classes = len(np.unique(y))

        # Fit prior

        # Sparse coding of labels
        sparse_y = np.zeros(shape=(n, nb_classes))
        sparse_y[np.arange(n), y] = 1

        self.prior = sparse_y.sum(axis=0) / n

        # Fit likelihood
        counts = sparse_y.T @ X + self.alpha
        self.likelihood = counts / counts.sum(axis=1).reshape(-1, 1)

        return self

    def get_posterior(self, X: np.ndarray) -> np.ndarray:
        """Returns the  posterior of X for every y.
            In other words, it returns the probability P(X | y)

        Parameters
        ----------
        X : array of shape (n_samples, n_features)
            Vectors, where n_samples is the number of samples and
            n_features is the number of features.

        Return
        ------
        posterior : array of shape (n_samples, n_classes)
        """

        posteriors = np.zeros(shape=(X.shape[0], self.prior.shape[0]))
        for i, x in enumerate(X):
            "*** YOUR CODE HERE ***"
            pass


        return posteriors



    def predict(self, X: np.ndarray) -> np.ndarray:
        """Returns the  class of X from the learned model.
        hat{y} = \arg\max_y P(y) \prod_{i = 1}^{n} P(x_i \mid y)

        Astuce: souvenez-vous de la méthode `argmax` de NumPy dans le TP1 et l'argument `axis`.

        Parameters
        ----------
        X : array of shape (n_samples, n_features)
            Vectors, where n_samples is the number of samples and
            n_features is the number of features.

        Return
        ------
        predicted_classes : array of shape (n_samples)

        """
        "*** YOUR CODE HERE ***"
        pass


def preprocess_data(max_features=3):
    """
    Preprocessing data

    Parameters
    ---------
    max_features : integer representing the maximum number of features used to encode each text

    """
    # Reading the csv file
    data = pd.read_csv('data/langid.csv')
    # data = data[data.language.isin(['French', 'Spanish', 'English'])]

    data_text, data_lang = data["Text"], data["language"]

    # Encoding languages -- target variable
    encoder = LabelEncoder()
    y = encoder.fit_transform(data_lang)

    # Removing non-alphabetical characters,
    reg_exp = "^[a-zA-Z]"
    data_text_clean = []
    for text in data_text:
        data_text_clean.append(re.sub(reg_exp, " ", text).lower())

    # Vectorizing  data text
    vectorizer = CountVectorizer(max_features=max_features)
    X = vectorizer.fit_transform(data_text_clean).toarray()

    # Splitting data into train and test
    x_train, x_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    return x_train, x_test, y_train, y_test, encoder, vectorizer


def plot_confusion_matrix(y_true, y_pred, label_names):
    mat = confusion_matrix(y_true, y_pred)
    sns.heatmap(mat.T, square=True, annot=True, fmt='d', cbar=False,
                xticklabels=label_names,
                yticklabels=label_names)
    plt.xlabel('true label')
    plt.ylabel('predicted label')
    plt.show()


if __name__ == '__main__':

    # Reading data to train and test the model
    X_train, X_test, y_train, y_test, label_encoder, vectorizer = preprocess_data(max_features=200)

    # Fit model and predict test labels
    y_pred = NaiveBayesClassifier().fit(X_train, y_train).predict(X_test)

    # Plot confusion matrix of the learned model on test data
    plot_confusion_matrix(y_test, y_pred, label_encoder.inverse_transform(np.unique(y_train)))

    MultinomialNB().fit(X_train, y_train)
